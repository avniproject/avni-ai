subjects - household, chronic spot, waste picker, feeder
programs - waste collection, chronic spot
encounters - chronic spot followup, collection and segregation and waste weight (feeder location)

